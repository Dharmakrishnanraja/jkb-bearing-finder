const fs=require('fs'),zlib=require('zlib');
const EQ=require('./equiv.js');
const d=JSON.parse(fs.readFileSync('jkb_data.json','utf8'));
const SO=JSON.parse(fs.readFileSync('skf_origin.json','utf8')),SKI=d.meta.brands.indexOf('SKF');
const T=d.meta.types,sigs=[],idx=new Map();let ok=0;
const FILL=new Set(['DG','SB','SR','CR','TR','TH','AC','AD','TX']),info=[];
const NOEQ=t=>/^(Unit – |Insert Bearing – )/.test(t)&&!/\((UC|UCP|UCF|UCFC|UCFL|UCT)\)/.test(t);
d.rows.forEach((r,n)=>{r.length=8;const og=()=>r[1]===SKI?(SO[r[0]]||2):0;const p=NOEQ(T[r[2]])?null:EQ.parse(r[0],T[r[2]]);
  if(!p){r.push(-1,0,og());info.push(null);return}
  info.push(p);
  let g=idx.get(p.sig);if(g===undefined){g=sigs.length;sigs.push(p.sig);idx.set(p.sig,g)}
  r.push(g,p.x?1:0,og());ok++});
d.meta.sigs=sigs;d.meta.ver=new Date().toISOString().slice(0,19);
// fill missing d/D/B from other rows of the same base (only when all known values agree)
const dm=new Map();
d.rows.forEach((r,n)=>{const p=info[n];if(!p||!FILL.has(p.fam)||r[3]==null)return;const k=p.base,v=r[3]+'|'+r[4]+'|'+r[5];const o=dm.get(k);if(!o)dm.set(k,{v:v,ok:true,r:[r[3],r[4],r[5]]});else if(o.v!==v)o.ok=false});
let filled=0;
d.rows.forEach((r,n)=>{const p=info[n];if(!p||!FILL.has(p.fam)||r[3]!=null)return;const o=dm.get(p.base);if(o&&o.ok){r[3]=o.r[0];r[4]=o.r[1];r[5]=o.r[2];filled++}});
console.log('dimension filled',filled);
const s=JSON.stringify(d);fs.writeFileSync('jkb_data.eq.json',s);
fs.writeFileSync('jkb_data.eq.json.gz',zlib.gzipSync(s,{level:9}));
console.log('parsed',ok,'of',d.rows.length,'sigs',sigs.length,'MB',(s.length/1e6).toFixed(2),'gz',(fs.statSync('jkb_data.eq.json.gz').size/1e6).toFixed(2));
