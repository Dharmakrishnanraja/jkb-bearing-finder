# JKB app builder: tpl.html + logos + data -> JKB_Bearing_Finder.html
import re,json,base64,shutil
t=open('tpl.html',encoding='utf-8').read()
L=json.load(open('logos.json'))
# ---- logos (white plate, no border) ----
t=t.replace('const LOGO=window.JKB_BRAND_LOGOS||{};','const LOGO=Object.assign(__LOGOS__,window.JKB_BRAND_LOGOS||{});\nconst EMB="__DATA__";\n/* தேடல்/Discount வரிசை முன்னுரிமை */\nconst ORDER=["SKF","NSK","FAG","NTN","TIMKEN","NRB","NBC","ZKL"];')
t=t.replace('<span class="bl" style="background:#fff"><img src="${LOGO[b]}"></span>','<span class="bl lg"><img src="${LOGO[b]}" alt="${b}"></span>')
t=t.replace('.bl img{height:20px;display:block}','.bl.lg{background:#fff;border-radius:10px;padding:3px 8px;height:40px;min-width:68px;box-shadow:none}.bl img{height:32px;max-width:120px;object-fit:contain;display:block}td .bl.lg{height:38px}')
t=t.replace('.chip{display:inline-flex;align-items:center;gap:8px;border:1px solid var(--gl);background:rgba(255,255,255,.07);color:#fff;border-radius:30px;padding:6px 12px 6px 7px;','.chip{display:inline-flex;align-items:center;gap:8px;border:0;background:rgba(255,255,255,.1);color:#fff;border-radius:16px;padding:4px 12px 4px 4px;')
t=t.replace('.chip.on{background:linear-gradient(135deg,var(--o1),var(--o2));border-color:transparent;box-shadow:0 6px 22px rgba(255,90,0,.5)}','.chip.on{background:linear-gradient(135deg,var(--o1),var(--o2));box-shadow:0 0 0 3px #fff,0 6px 22px rgba(255,90,0,.6)}')
# ---- boot: newest of embedded / fetched / picked ----
i=t.index('async function boot()');j=t.index('function start(d)')
t=t[:i]+'''const b64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0)).buffer;
async function boot(){const c=[];
  try{c.push(await parse(b64(EMB)))}catch(e){}
  try{const r=await fetch(DATA_URL,{cache:"no-cache"});if(r.ok)c.push(await parse(await r.arrayBuffer()))}catch(e){}
  const k=await cget();if(k)c.push(k);
  if(!c.length){$("lmsg").textContent="டேட்டா கிடைக்கவில்லை";return}
  c.sort((a,b)=>(b.meta.ver||"").localeCompare(a.meta.ver||""));start(c[0])}
$("file2").onchange=async e=>{const d=await parse(await e.target.files[0].arrayBuffer());await cput(d);location.reload()};
'''+t[j:]
t=t.replace('டேட்டா ${META.built}`','டேட்டா பதிப்பு ${(META.ver||"பழையது").replace("T"," ")}`')
t=t.replace('<footer id="foot">JKB Bearing Finder</footer>','<footer><span id="foot">JKB Bearing Finder</span> · <label style="display:inline;cursor:pointer;color:#ffb066;font-weight:700">🔄 புதிய டேட்டா கோப்பு தேர்வு<input type="file" id="file2" accept=".gz,.json" hidden></label><span id="inst" hidden> · <a href="#" id="instb" style="color:#ffb066;font-weight:700;text-decoration:none">📲 App-ஆக நிறுவு</a></span><span id="ios" hidden> · 📲 iPhone: Share ▸ “Add to Home Screen”</span></footer>')
# ---- brand priority: SKF > NSK > FAG > NTN > TIMKEN > NRB > NBC > ZKL ----
t=t.replace('META=d.meta;ROWS=d.rows;KEY=ROWS.map(r=>norm(r[0]));','META=d.meta;ROWS=d.rows;KEY=ROWS.map(r=>norm(r[0]));\n  RK=META.brands.map(b=>{const p=ORDER.indexOf(b);return p<0?99:p});\n  BO=META.brands.map((b,i)=>i).sort((a,b)=>RK[a]-RK[b]);')
t=t.replace('let META,ROWS=[]','let RK=[],BO=[],TI=null,META,ROWS=[]')
t=t.replace('META.brands.forEach(b=>disc[b]=35);restore();\n  $("dg").innerHTML=META.brands.map(b=>','META.brands.forEach(b=>disc[b]=35);restore();\n  $("dg").innerHTML=BO.map(i=>META.brands[i]).map(b=>')
# search ordering
t=t.replace('''    const a=[],b=[];for(let i=0;i<ROWS.length;i++){const k=KEY[i],p=k.indexOf(q);if(p===0)(k===q?t0:a).push(i);else if(p>0)b.push(i)}
    res=t0.concat(a,b)}''','''    TI=new Uint8Array(ROWS.length);for(let i=0;i<ROWS.length;i++){const k=KEY[i],p=k.indexOf(q);if(p>=0){TI[i]=k===q?0:p===0?1:2;t0.push(i)}}
    res=t0.sort((a,b)=>RK[ROWS[a][1]]-RK[ROWS[b][1]]||TI[a]-TI[b]||KEY[a].length-KEY[b].length)}''')
t=t.replace('      if(ok)t0.push(i)}\n    res=t0}','      if(ok)t0.push(i)}\n    res=t0.sort((a,b)=>RK[ROWS[a][1]]-RK[ROWS[b][1]]||(KEY[a]<KEY[b]?-1:1))}')
t=t.replace('Object.keys(c).sort((a,b)=>c[b]-c[a]).map(','BO.filter(b=>c[b]).map(')
# ---- intro animation (original SVG/CSS) ----
css='''#intro{position:fixed;inset:0;z-index:40;background:radial-gradient(800px 500px at 50% 45%,#2a1205,#0a0a0d 70%);display:flex;flex-direction:column;align-items:center;justify-content:center;transition:opacity .9s,transform .9s}
#intro.out{opacity:0;transform:scale(1.15);pointer-events:none}
#intro svg{width:min(78vw,340px);height:auto;overflow:visible;filter:drop-shadow(0 0 30px rgba(255,90,0,.5))}
#intro .pc{transform-box:fill-box;transform-origin:center;opacity:0;animation:fin 1.5s cubic-bezier(.2,.9,.25,1) forwards;animation-delay:var(--d)}
@keyframes fin{from{opacity:0;transform:translate(var(--x),var(--y)) rotate(var(--r)) scale(.3)}to{opacity:1;transform:none}}
#intro .sp{transform-box:fill-box;transform-origin:center;animation:sp 3.2s linear 1.6s infinite}@keyframes sp{to{transform:rotate(360deg)}}
#intro .lg{opacity:0;animation:lg 1s ease 1.7s forwards}@keyframes lg{from{opacity:0;transform:scale(.4)}to{opacity:1;transform:scale(1)}}
#intro .tt{opacity:0;text-align:center;animation:up .9s ease 2.2s forwards;margin-top:18px}@keyframes up{from{opacity:0;transform:translateY(18px)}to{opacity:1}}
#intro h2{margin:0;font-size:clamp(22px,5vw,36px);color:#fff;letter-spacing:2px}#intro h2 b{color:var(--o1)}#intro p{margin:6px 0 0;color:var(--mut);letter-spacing:3px;font-size:12px}
#intro button{position:absolute;right:20px;bottom:20px;background:rgba(255,255,255,.1);color:#fff;border:1px solid var(--gl);border-radius:20px;padding:8px 16px;font:inherit;cursor:pointer}
@media(prefers-reduced-motion:reduce){#intro{display:none}}
'''
t=t.replace('@media print{',css+'@media print{',1)
html='''<div id="intro"><svg viewBox="0 0 300 300" id="isvg"><defs><linearGradient id="gm" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f4f4f6"/><stop offset=".5" stop-color="#8d929c"/><stop offset="1" stop-color="#e6e8ee"/></linearGradient><linearGradient id="go" x1="0" x2="1"><stop offset="0" stop-color="#ff9a1f"/><stop offset="1" stop-color="#ff3d00"/></linearGradient></defs>
<g id="ig"></g></svg>
<div class="tt"><h2>JAYAKUMAR <b>BEARINGS</b></h2><p>BEARING PRICE FINDER</p></div><button id="skip">Skip ⏭</button></div>
'''
t=t.replace('<div class="orb o1">',html+'<div class="orb o1">',1)
js='''
/* ---------- தொடக்க அனிமேஷன்: பாகங்கள் பறந்து வந்து பேரிங்காக இணையும் ---------- */
(()=>{const g=$("ig"),N="http://www.w3.org/2000/svg",R=(a)=>(Math.random()*2-1)*a;
  const add=(tag,at,d)=>{const e=document.createElementNS(N,tag);for(const k in at)e.setAttribute(k,at[k]);e.setAttribute("class","pc");
    e.style.cssText=`--x:${R(260)}px;--y:${R(260)}px;--r:${R(200)}deg;--d:${d}s`;return e};
  g.appendChild(add("circle",{cx:150,cy:150,r:128,fill:"none",stroke:"url(#gm)","stroke-width":26},0));
  g.appendChild(add("circle",{cx:150,cy:150,r:66,fill:"none",stroke:"url(#gm)","stroke-width":20},.15));
  const s=document.createElementNS(N,"g");s.setAttribute("class","sp");g.appendChild(s);
  for(let i=0;i<12;i++){const a=i*Math.PI/6;s.appendChild(add("circle",{cx:150+97*Math.cos(a),cy:150+97*Math.sin(a),r:15,fill:"url(#go)"},.3+i*.09))}
  const im=document.createElementNS(N,"image");im.setAttribute("href","data:image/jpeg;base64,__LOGO__");im.setAttribute("x",108);im.setAttribute("y",108);im.setAttribute("width",84);im.setAttribute("height",84);im.setAttribute("class","lg");im.style.cssText="transform-box:fill-box;transform-origin:center;clip-path:circle(50%)";g.appendChild(im);
  const done=()=>{const i=$("intro");if(!i)return;i.classList.add("out");setTimeout(()=>i.remove(),1000)};
  $("skip").onclick=done;$("intro").onclick=done;setTimeout(done,4800)})();
'''
t=t.replace('boot();\n})();',js+'boot();\n})();')

# ---- equivalence engine + UI ----
eqjs=open('equiv.js',encoding='utf-8').read().replace('if(typeof module!=="undefined")module.exports=JKBEQ;','')
equi=open('eq_ui.js',encoding='utf-8').read()
t=t.replace('/*__EQJS__*/',eqjs+'\n'+equi)
t=t.replace('__TIMGS__',open('type_imgs.json',encoding='utf-8').read())
t=t.replace('/*__QJS__*/',open('quote.js',encoding='utf-8').read())
t=t.replace('$("load").style.display="none";run()}','eqIndex();$("load").style.display="none";run()}')
t=t.replace('function run(){const t0=[];eqSet(mode==="num"?$("q").value:"");','function run(){const t0=[];eqSet(mode==="num"?$("q").value:"");EQ.act=null;EQ.set=null;')
assert 'res=t0.sort((a,b)=>RK[ROWS[a][1]]-RK[ROWS[b][1]]||TI[a]-TI[b]||KEY[a].length-KEY[b].length)}' in t
t=t.replace('res=t0.sort((a,b)=>RK[ROWS[a][1]]-RK[ROWS[b][1]]||TI[a]-TI[b]||KEY[a].length-KEY[b].length)}','res=eqApply(t0.sort((a,b)=>RK[ROWS[a][1]]-RK[ROWS[b][1]]||TI[a]-TI[b]||KEY[a].length-KEY[b].length))}')

assert t.rstrip().endswith('</script></body></html>');t=t[:t.rindex('</script></body></html>')]+('\n/* ---- PWA: service worker (only when served over http/https) + install button ---- */\nif("serviceWorker"in navigator&&/^https?:/.test(location.protocol)){addEventListener("load",()=>{navigator.serviceWorker.register("sw.js").catch(()=>{})})}\nlet _ip=null;addEventListener("beforeinstallprompt",e=>{e.preventDefault();_ip=e;const x=document.getElementById("inst");if(x)x.hidden=false});\ndocument.addEventListener("click",e=>{if(e.target.id==="instb"){e.preventDefault();if(_ip){_ip.prompt();_ip=null;document.getElementById("inst").hidden=true}}});\naddEventListener("appinstalled",()=>{const x=document.getElementById("inst");if(x)x.hidden=true});\ntry{if(/iphone|ipad/i.test(navigator.userAgent)&&!navigator.standalone&&window.parent===window&&/^https?:/.test(location.protocol)){const o=document.getElementById("ios");if(o)o.hidden=false}}catch(e){}\n'+'</script></body></html>') 
# ---- finalize ----
t=t.replace('__LOGO__',open('logo.b64').read()).replace('__DIM__',open('dim.b64').read())
t=t.replace('__LOGOS__',json.dumps(L)).replace('__DATA__',base64.b64encode(open('jkb_data.eq.json.gz','rb').read()).decode())
open('/mnt/user-data/outputs/JKB_Bearing_Finder.html','w',encoding='utf-8').write(t)
open('/tmp/a.js','w').write(re.search(r'<script>(.*)</script>',t,re.S).group(1))
shutil.copy('jkb_data.eq.json.gz','/mnt/user-data/outputs/jkb_data.json.gz');shutil.copy('jkb_data.eq.json','/mnt/user-data/outputs/jkb_data.json')
for f in ['build_data.py','build_app.py','add_sigs.js','equiv.js']: shutil.copy(f,'/mnt/user-data/outputs/'+f)
print(round(len(t)/1e6,2),'MB')
