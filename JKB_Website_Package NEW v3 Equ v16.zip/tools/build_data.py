# JKB data builder: CSV -> compact jkb_data.json (+ .gz). Run again whenever price lists change.
import pandas as pd, json, gzip, sys, glob
src = sys.argv[1] if len(sys.argv)>1 else '/mnt/user-data/uploads/JKB_FULL_MULTI_BRAND_BEARING_DATABASE_2026_Website_Import__1_.csv'
df = pd.read_csv(src, encoding='utf-8-sig', low_memory=False)
df['exact_designation']=df.exact_designation.astype(str).str.replace('\xa0',' ').str.strip()
rank={'PRICE':0,'PRICE_ON_REQUEST':1,'NOT_AVAILABLE':2}
df['r']=df.price_status.map(rank)
df=df.sort_values(['brand','exact_designation','r'])
brands=sorted(df.brand.unique()); types=sorted(df.canonical_type.fillna('Others').unique())
rows=[]
for (b,d),g in df.groupby(['brand','exact_designation'],sort=False):
    best=g.iloc[0]
    dims=[None,None,None]
    for i,c in enumerate(['bore_d_mm','outer_D_mm','width_B_mm']):
        v=g[c].dropna()
        if len(v): dims[i]=float(v.iloc[0]); dims[i]=int(dims[i]) if dims[i]==int(dims[i]) else dims[i]
    rsp=best.RSP_or_Source_Price_INR
    rows.append([d,brands.index(b),types.index(best.canonical_type if isinstance(best.canonical_type,str) else 'Others'),
                 *dims, None if pd.isna(rsp) else float(rsp), int(best.r)])
import datetime
meta={'built':'2026-10-06','ver':datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S'),'brands':brands,
 # basis (எல்லா brand-க்கும் 'excl' = RSP-ல் discount கழித்து GST தனியாக சேர்க்கப்படும்) # old: 'incl' = list is MRP inclusive of GST (NRB, TIMKEN); 'excl' = GST added on top (others)
 'basis':{b:'excl' for b in brands},
 'types':types,'count':len(rows)}
out={'meta':meta,'rows':rows}
s=json.dumps(out,separators=(',',':'),ensure_ascii=False)
open('jkb_data.json','w',encoding='utf-8').write(s)
open('jkb_data.json.gz','wb').write(gzip.compress(s.encode(),9))
print(len(rows),len(s)/1e6,'MB json',len(gzip.compress(s.encode(),9))/1e6,'MB gz')
