import json,re,base64,io
from PIL import Image
A=json.load(open('/home/claude/hu/A.json'))
TYPES=[ # (name, image)
 ("Unit – Insert Bearing with Set Screws, Metric (UC)","i-003-008"),
 ("Unit – Pillow Block, Metric Series (UCP)","i-003-009"),
 ("Unit – Pillow Block, Inch Series (UCP)","i-005-014"),
 ("Unit – Square 4-Bolt Flange, Metric Series (UCF)","i-004-010"),
 ("Unit – Square 4-Bolt Flange, Inch Series (UCF)","i-006-015"),
 ("Unit – Round 4-Bolt Flange (UCFC)","i-004-011"),
 ("Unit – Oval 2-Bolt Flange (UCFL)","i-004-012"),
 ("Unit – Take Up (UCT)","i-005-013"),
 ("Unit – ISO Series Pillow Block (SY)","i-007-016"),
 ("Unit – ISO Series Take Up (TU)","i-008-017"),
 ("Unit – ISO Series Four Bolt Square Flange (FY)","i-008-018"),
 ("Unit – ISO Series Two Bolt Oval Flange (FYTB)","i-009-020"),
 ("Unit – JIS Series Short Base Pillow Block (SYF)","i-010-021"),
 ("Unit – JIS Series Pillow Block (SYJ)","i-010-022"),
 ("Unit – JIS Series Four Bolt Square Flange (FYJ)","i-011-024"),
 ("Unit – JIS Series Two Bolt Oval Flange (FYTJ)","i-011-025"),
 ("Unit – JIS Series Four Bolt Circular Flange (FYC)","i-012-027"),
 ("Unit – JIS Series Take Up (TUJ)","i-012-028"),
 ("Insert Bearing – Two Grub Screw Locking (YAR / YAT)","i-012-029"),
 ("Insert Bearing – Eccentric Locking Collar (YEL / YET)","i-014-032"),
 ("Insert Bearing – Adapter Sleeve Locking (YSA)","i-015-033"),
 ("Unit – End Cover (ECY)","i-016-036"),
 ("Unit – Blue Line Two Bolt Oval Flange (F2B)","i-016-037"),
 ("Unit – Blue Line Three Bolt Bracket Flange (F3BB)","i-016-038"),
 ("Unit – Blue Line Four Bolt Square Flange (F4B)","i-016-039"),
 ("Unit – Blue Line Take Up (WSTU)","i-016-040"),
 ("Unit – Blue Line Pillow Block (P2B)","i-017-041"),
]
PFX={'UC':0,'UCP':1,'UCF':3,'UCFC':5,'UCFL':6,'UCT':7,'SY':8,'TU':9,'FY':10,'FYTB':11,'SYF':12,'SYJ':13,'FYJ':14,'FYTJ':15,'FYC':16,'TUJ':17,'YAR':18,'YAT':18,'YEL':19,'YET':19,'YSA':20,'ECY':21,'F2BC':22,'F2BSS':22,'F3BBC':23,'F4BC':24,'F4BSS':24,'WSTUC':25,'P2BC':26}
d=json.load(open('jkb_data.pre_hu.json'))
M=d['meta'];base=len(M['types'])
for n,_ in TYPES:
    if n not in M['types']:M['types'].append(n)
tidx={n:M['types'].index(n) for n,_ in TYPES}
skf=M['brands'].index('SKF')
exist={(r[1],re.sub(r'[^A-Z0-9]','',r[0].upper())) for r in d['rows']}
new=[];origin={};dup=0
for x in A:
    des=re.sub(r'\s+',' ',x['des']).strip();p=des.split(' ')[0]
    ti=PFX[p]
    if p in('UCP','UCF') and 'Inch' in (x['sec'] or ''): ti+=1
    price=None if '*' in x['price'] else float(x['price'].replace(',',''))
    key=(skf,re.sub(r'[^A-Z0-9]','',des.upper()))
    if key in exist: dup+=1;print('DUP',des);continue
    m=re.search(r'shaft dia ([\d.]+)mm',x['desc']);dia=float(m.group(1)) if m else None
    if dia is not None and dia==int(dia):dia=int(dia)
    new.append([des,skf,tidx[TYPES[ti][0]],dia,None,None,price,0 if price is not None else 1])
    origin[des]=x['origin']
d['rows'].extend(new)
json.dump(d,open('jkb_data.json','w'),ensure_ascii=False,separators=(',',':'))
json.dump(origin,open('/home/claude/hu/hu_origin.json','w'),ensure_ascii=False)
print('added',len(new),'dups',dup,'types',base,'->',len(M['types']))
# images
imgs={}
for n,f in TYPES:
    im=Image.open(f'/home/claude/hu/img/{f}.png').convert('RGBA')
    bg=Image.new('RGBA',im.size,(255,255,255,255));bg.alpha_composite(im);im=bg.convert('RGB')
    # trim white border
    from PIL import ImageChops
    diff=ImageChops.difference(im,Image.new('RGB',im.size,(255,255,255))).convert('L').point(lambda v:255 if v>14 else 0)
    bb=diff.getbbox()
    if bb:im=im.crop(bb)
    im.thumbnail((170,170),Image.LANCZOS)
    c=Image.new('RGB',(im.width+16,im.height+16),'white');c.paste(im,(8,8))
    b=io.BytesIO();c.save(b,'JPEG',quality=84);imgs[n]='data:image/jpeg;base64,'+base64.b64encode(b.getvalue()).decode()
json.dump(imgs,open('type_imgs.json','w'))
print('imgs kb',sum(len(v) for v in imgs.values())//1024)
