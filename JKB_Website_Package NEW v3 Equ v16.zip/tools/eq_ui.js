/* ===================== Equivalent (இணை) panel ===================== */
const EQ={q:null,qp:null,base:null,act:null,av:null,set:null,ord:false};
let SIGIDX=new Map(),BASEIDX=new Map();
const baseOf=s=>s.startsWith("TI:")?s:s.split("|")[0];
function eqIndex(){SIGIDX=new Map();BASEIDX=new Map();
  if(!META.sigs)return;
  ROWS.forEach((r,i)=>{if(r[8]==null||r[8]<0)return;const s=META.sigs[r[8]];let a=SIGIDX.get(s);if(!a)SIGIDX.set(s,a=[]);a.push(i);
    const b=baseOf(s);let m=BASEIDX.get(b);if(!m)BASEIDX.set(b,m=new Set());m.add(s)})}
const bsOf=s=>{const o=new Set();(SIGIDX.get(s)||[]).forEach(i=>o.add(ROWS[i][1]));return o};
function eqSet(q){if(q===EQ.q)return;EQ.q=q;EQ.av=null;EQ.qp=null;EQ.base=null;
  if(!q.trim())return;const p=JKBEQ.parse(q,"");if(!p)return;EQ.qp=p;EQ.base=baseOf(p.sig)}
function eqPick(){EQ.act=null;EQ.ord=false;
  if(mode!=="num"||!EQ.base)return;const sg=BASEIDX.get(EQ.base);if(!sg)return;
  const all=new Set();sg.forEach(s=>bsOf(s).forEach(b=>all.add(b)));if(all.size<2)return;
  const p=EQ.qp;
  if(EQ.av&&sg.has(EQ.av)){EQ.act=EQ.av;EQ.ord=true;return}
  if(p&&!p.x&&!p.plain&&sg.has(p.sig)){EQ.act=p.sig;EQ.ord=true;return}
  let best=null,bn=-1;sg.forEach(s=>{const n=bsOf(s).size;if(n>bn){bn=n;best=s}});EQ.act=best}
function eqApply(r){EQ.set=null;eqPick();if(!EQ.act||!EQ.ord)return r;
  const g=(SIGIDX.get(EQ.act)||[]).filter(i=>ROWS[i][9]===0);EQ.set=new Set(g);
  const first=g.slice().sort((a,b)=>RK[ROWS[a][1]]-RK[ROWS[b][1]]||ROWS[a][9]-ROWS[b][9]||KEY[a].length-KEY[b].length);
  return first.concat(r.filter(i=>!EQ.set.has(i)))}
const SEALN={O:["Open","மூடி இல்லை (திறந்த வகை)"],Z2:["Double Shield","இரு பக்கமும் உலோக மூடி · 2Z / ZZ"],Z1:["Single Shield","ஒரு பக்கம் உலோக மூடி · Z"],R2:["Double Rubber Seal","இரு பக்கமும் ரப்பர் சீல் · 2RS / LLU / DDU / 2RSR"],R1:["Single Rubber Seal","ஒரு பக்கம் ரப்பர் சீல் · RS / LU / DU"],N2:["Double Non-contact","இரு பக்கமும் தொடாத ரப்பர் சீல் · 2RZ / LLB / VV"],N1:["Single Non-contact","ஒரு பக்கம் தொடாத சீல் · RZ / LB"]};
const PARTN={C2:["C2","சாதாரணத்தை விட குறைந்த இடைவெளி"],C3:["C3","சாதாரணத்தை விட அதிக இடைவெளி (மோட்டார் / சூடான இடம்)"],C4:["C4","C3-யை விட அதிக இடைவெளி"],C5:["C5","மிக அதிக இடைவெளி"],C6:["C6","மிக அதிக இடைவெளி"],CM:["CM","மோட்டாருக்கான சிறப்பு இடைவெளி (NSK)"],NR:["Snap ring","Snap-ring groove + ring (NR)"],N:["Ring groove","Snap-ring groove (N)"],K:["Taper bore","டேப்பர் துளை 1:12 (K)"],K30:["Taper 1:30","டேப்பர் துளை 1:30 (K30)"],BR:["Brass cage","பித்தளை கூண்டு (M / MA)"],aA:["30° angle","30° contact angle (A)"],aB:["40° angle","40° contact angle (B)"],aC:["15° angle","15° contact angle (C)"],aAC:["25° angle","25° contact angle (AC)"],DB:["Pair DB","ஜோடி – back to back"],DF:["Pair DF","ஜோடி – face to face"],DT:["Pair DT","ஜோடி – tandem"]};
function lab(sig){if(sig.startsWith("TI:"))return{en:"Cone / Cup",ta:"அதே cone / cup எண்"};
  const en=[],ta=[];sig.split("|").slice(1).forEach(x=>{const m=SEALN[x]||PARTN[x];if(m){en.push(m[0]);ta.push(m[1])}else{en.push(x);ta.push(x)}});
  return en.length?{en:en.join(" · "),ta:ta.join("  +  ")}:{en:"Standard",ta:"நிலையான வகை (அளவு மட்டும் ஒன்றே)"}}
const FAMN={DG:"Deep Groove Ball",SB:"Self-Aligning Ball",AC:"Angular Contact Ball",AD:"Double-row Angular Contact",SR:"Spherical Roller",CR:"Cylindrical Roller",TR:"Tapered Roller",TI:"Tapered Roller (Inch)",TH:"Thrust Ball",TX:"Thrust Roller",P:"Needle / Special",G:"Bearing"};
function ico(f){const C=32,rows=[];const cl="url(#gs)";let els="";
  const n=(f==="CR"||f==="TR"||f==="TI"||f==="SR"||f==="TX"||f==="P")?10:9;
  for(let k=0;k<n;k++){const a=k*2*Math.PI/n,x=C+19.5*Math.cos(a),y=C+19.5*Math.sin(a),d=a*180/Math.PI+90;
    if(f==="SR")els+=`<ellipse cx="${x}" cy="${y}" rx="3.2" ry="5" transform="rotate(${d} ${x} ${y})" fill="url(#go)"/>`;
    else if(f==="CR"||f==="TX")els+=`<rect x="${x-2.8}" y="${y-4.6}" width="5.6" height="9.2" rx="1" transform="rotate(${d} ${x} ${y})" fill="url(#go)"/>`;
    else if(f==="TR"||f==="TI")els+=`<polygon points="${x-3.6},${y-5} ${x+3.6},${y-5} ${x+2},${y+5} ${x-2},${y+5}" transform="rotate(${d} ${x} ${y})" fill="url(#go)"/>`;
    else if(f==="P")els+=`<rect x="${x-1.5}" y="${y-5.5}" width="3" height="11" rx="1.2" transform="rotate(${d} ${x} ${y})" fill="url(#go)"/>`;
    else els+=`<circle cx="${x}" cy="${y}" r="${f==="TH"?3:4.1}" fill="url(#go)"/>`}
  const extra=f==="SB"?`<circle cx="32" cy="32" r="29" fill="none" stroke="#ffb066" stroke-width="1.2" stroke-dasharray="3 3"/>`:(f==="AC"||f==="AD")?`<path d="M6 58 L58 6" stroke="#ffb066" stroke-width="1.4" stroke-dasharray="3 3"/>`:"";
  return `<svg viewBox="0 0 64 64"><defs><linearGradient id="gs" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f4f4f6"/><stop offset=".5" stop-color="#8d929c"/><stop offset="1" stop-color="#e6e8ee"/></linearGradient><linearGradient id="go" x1="0" x2="1"><stop offset="0" stop-color="#ff9a1f"/><stop offset="1" stop-color="#ff3d00"/></linearGradient></defs>
  <circle cx="32" cy="32" r="28" fill="none" stroke="${cl}" stroke-width="6"/><circle cx="32" cy="32" r="11" fill="none" stroke="${cl}" stroke-width="5"/><g class="rot">${els}</g>${extra}<circle cx="32" cy="32" r="4" fill="#0a0a0d"/></svg>`}
const GUIDE=[
 ["Double Shield · இரு உலோக மூடி",{SKF:"2Z",NSK:"ZZ",FAG:"2Z",NTN:"ZZ",TIMKEN:"ZZ",NRB:"ZZ",NBC:"ZZ",ZKL:"2Z"}],
 ["Single Shield · ஒரு உலோக மூடி",{SKF:"Z",NSK:"Z",FAG:"Z",NTN:"Z",TIMKEN:"Z",NRB:"Z",NBC:"Z",ZKL:"Z"}],
 ["Double Rubber Seal · இரு ரப்பர் சீல்",{SKF:"2RS1 / 2RSH",NSK:"DDU",FAG:"2RSR",NTN:"LLU",TIMKEN:"2RS",NRB:"2RS",NBC:"LLU / RSS",ZKL:"2RS"}],
 ["Single Rubber Seal · ஒரு ரப்பர் சீல்",{SKF:"RS1 / RSH",NSK:"DU",FAG:"RSR",NTN:"LU",TIMKEN:"RS",NRB:"RS",NBC:"LU",ZKL:"RS"}],
 ["Double Non-contact · தொடாத சீல்",{SKF:"2RZ",NSK:"VV",FAG:"2RZ",NTN:"LLB",TIMKEN:"2RZ",NRB:"—",NBC:"LLB",ZKL:"—"}],
 ["Clearance C3 · அதிக இடைவெளி",{SKF:"/C3",NSK:"C3",FAG:"-C3",NTN:"C3",TIMKEN:"-C3",NRB:"C3",NBC:"C3",ZKL:"C3"}],
 ["Brass Cage · பித்தளை கூண்டு",{SKF:"M / MA",NSK:"M",FAG:"M / MA",NTN:"M",TIMKEN:"M",NRB:"M",NBC:"M",ZKL:"M"}],
 ["Spherical Roller · design எழுத்து",{SKF:"E / CC",NSK:"EAE4 / CAME4",FAG:"E1-XL",NTN:"EAD1 / EMD1",TIMKEN:"EJ / EMB",NRB:"EAB33",NBC:"CC / MB",ZKL:"EJ / CW"}],
 ["Cylindrical Roller · design எழுத்து",{SKF:"ECP / ECJ",NSK:"E / ET / W",FAG:"E-XL",NTN:"E / ET2X",TIMKEN:"ETP / EMA",NRB:"EP / EM",NBC:"E",ZKL:"E / M"}]];
function eqGuide(){const bs=ORDER.filter(b=>META.brands.includes(b));
  $("eqw").innerHTML="<table><thead><tr><th>வகை</th>"+bs.map(b=>`<th>${LOGO[b]?`<img src="${LOGO[b]}" alt="${b}">`:b}</th>`).join("")+"</tr></thead><tbody>"+
   GUIDE.map(g=>`<tr><td>${g[0]}</td>`+bs.map(b=>`<td>${g[1][b]||"—"}</td>`).join("")+"</tr>").join("")+"</tbody></table>"}
let guided=false;
function eqDraw(){const P=$("eqp"),J=$("eqj");if(!EQ.act||!EQ.base){P.hidden=true;J.hidden=true;return}
  J.hidden=false;J.textContent=`🔁 இணை பேரிங்கள் (${bsOf(EQ.act).size}/${META.brands.length} brands) பார்க்க ↓`;
  P.hidden=false;if(!guided){eqGuide();guided=true}
  const sg=[...BASEIDX.get(EQ.base)].sort((a,b)=>bsOf(b).size-bsOf(a).size||(a<b?-1:1));
  const nb=META.brands.length,ab=bsOf(EQ.act).size,fam=EQ.qp?EQ.qp.fam:"G";
  let d=null;for(const s of sg){for(const i of (SIGIDX.get(s)||[])){if(ROWS[i][3]!=null){d=ROWS[i];break}}if(d)break}
  $("eqi").innerHTML=ico(fam);$("eqn").textContent=EQ.base.replace(/^TI:/,"");
  $("eqd").innerHTML=`<span class="ty">${FAMN[fam]||"Bearing"}</span>`+(d?`<span>d ${d[3]}</span><span>D ${d[4]??"-"}</span><span>W ${d[5]??"-"}</span>`:"");
  $("eqc").innerHTML=`${ab} / ${nb}<br><small style="font-weight:700">Brands</small>`;
  $("eqv").innerHTML=sg.map(s=>{const l=lab(s);return`<button data-s="${s}" class="${s===EQ.act?"on":""}">${l.en}<small>${bsOf(s).size} / ${nb} brands</small></button>`}).join("");
  {const a=$("eqv").querySelector(".on");if(a)$("eqv").scrollLeft=Math.max(0,a.offsetLeft-24)}
  $("eqx").innerHTML=`<b>${lab(EQ.act).en}</b> – ${lab(EQ.act).ta}`;
  const rows=SIGIDX.get(EQ.act)||[];let h="";
  ORDER.filter(b=>META.brands.includes(b)).forEach(b=>{const bi=META.brands.indexOf(b);
    const mine=rows.filter(i=>ROWS[i][1]===bi).sort((a,c)=>ROWS[a][9]-ROWS[c][9]||ROWS[a][7]-ROWS[c][7]||KEY[a].length-KEY[c].length);
    const lg=LOGO[b]?`<img src="${LOGO[b]}" alt="${b}">`:`<b style="color:#111">${b}</b>`;
    if(!mine.length){h+=`<div class="eq1 miss"><div class="lgp">${lg}</div><div class="ms">இந்த வகை இல்லை<br>Not in list</div></div>`;return}
    const i=mine[0],r=ROWS[i],c=calc(r),alt=mine.filter(k=>k!==i&&ROWS[k][9]===0&&ROWS[k][0]!==r[0]);
    h+=`<div class="eq1" data-i="${i}" style="--bc:${(BC[b]||["#ff7a00"])[0]}"><div class="lgp">${lg}</div>${obadge(r)?`<div style="text-align:center">${obadge(r)}</div>`:""}<div class="dn">${r[0]}</div>`+
     (alt.length?`<div class="al">அல்லது: ${ROWS[alt[0]][0]}${alt.length>1?" +"+(alt.length-1):""}</div>`:`<div class="al">${r[9]?"special variant":"&nbsp;"}</div>`)+
     (c?`<div class="pb"><div><small>List Price</small><span>₹${inr(c.rsp)}</span></div><div class="tx"><small>Taxable Price</small><span>₹${inr(c.tx)}</span></div><div class="nn"><small>NETT PRICE</small><span>₹${inr(c.nett)}</span></div></div>`:`<div class="cf">${stat(r)}</div>`)+`</div>`});
  $("eqg").innerHTML=h}
function eqGo(i){const r=ROWS[i];if(brand!==""&&bkey(r)!==brand){brand="";paint()}
  const sel=(getComputedStyle($("cards")).display!=="none"?"#cards":"#tb")+` [data-i="${i}"]`;
  const el=document.querySelector(sel);if(!el)return;
  el.scrollIntoView({behavior:"smooth",block:"center"});el.classList.remove("fl");void el.offsetWidth;el.classList.add("fl")}
$("eqg").onclick=e=>{const t=e.target.closest(".eq1[data-i]");if(t)eqGo(+t.dataset.i)};
$("eqv").onclick=e=>{const b=e.target.closest("button[data-s]");if(b){EQ.av=b.dataset.s;run()}};

$("eqj").onclick=()=>{$("eqm").open=true;$("eqp").scrollIntoView({behavior:"smooth",block:"start"})};
