/* JKB Equivalent engine – one source of truth (used by build step AND by the app) */
var JKBEQ=(function(){
"use strict";
var SEAL_FULL=[["2RSH","R2"],["2RS1","R2"],["2RSL","R2"],["2RSR","R2"],["2RS2","R2"],["2RSZ","N2"],["2RS","R2"],["2HRS","R2"],["2LS2","R2"],["2LS","R2"],["MLLU","R2"],["LLU","R2"],["LLH","R2"],["DDU","R2"],["RSS","R2"],["DD","R2"],["LLB","N2"],["VV","N2"],["2RZ","N2"],["2Z","Z2"],["ZZ","Z2"],["RSH","R1"],["RS1","R1"],["RSL","R1"],["RSR","R1"],["RS2","R1"],["RS","R1"],["HRS","R1"],["MLU","R1"],["LU","R1"],["DU","R1"],["LB","N1"],["RZ","N1"],["V","N1"],["Z","Z1"]];
var SEAL_MID=SEAL_FULL.filter(function(e){return e[0]!=="V"&&e[0]!=="DD"&&e[0]!=="LB"&&e[0]!=="DU"});
var SEAL_MIN=[["2RS","R2"],["PP","R2"],["RS","R1"]];
var CLR=[["C0","CN"],["C1","C1"],["C2","C2"],["C3","C3"],["C4","C4"],["C5","C5"],["C6","C6"],["CN","CN"],["CM","CM"]];
var GRV=[["NR","NR"],["N","N"]];
var TAP=[["K30","K30"],["K","K"]];
var BRASS=[["MA","BR"],["MB","BR"],["M","BR"]];
var NEUT_DG=["2AS","3AS","5K","EMQ","INA020","INA0","TN9","TN1","TNG","TN","NF","E","C","A","Y","J","JR"];
var PAIR=[["DBD","DB"],["DB","DB"],["DF","DF"],["DT","DT"]];
var FLAG=/^(P\d{1,2}[A-Z]?|HT\d*|VA\d+|GJN|WT|LHT\d+|VT\d+|HTVT\d+|MT\d+|HDY\d|T1X|LT)/;
var CRP=/^(NNCF|NNU|NNF|NCF|NUP|NJP|NJ|NU|NF|NN|RNU|N)$/;
var TIP=/^(LM|HM|JLM|JM|HH|EE|L|M|JP|JH)$/;
var FAMS={DG:{seal:SEAL_FULL,clr:1,grv:1,tap:1,brass:1,neut:NEUT_DG,strict:1},
 SB:{seal:SEAL_MID,clr:1,tap:1},SR:{clr:1,tap:1},CR:{clr:1,tap:1,neut:["ECML","ECMA","ECM","ECP","ECJ"]},TR:{clr:1},TH:{clr:1},TX:{clr:1},
 AC:{seal:SEAL_MID,clr:1,ang:1,pair:1},AD:{seal:SEAL_MID,clr:1,ang:1,pair:1},
 P:{seal:SEAL_MIN,clr:1,strictDigit:1},G:{seal:SEAL_MID,clr:1,strictDigit:1}};
function build(list){return list.slice().sort(function(a,b){return b[0].length-a[0].length})}
var CACHE={};
function vocab(f){
 if(CACHE[f])return CACHE[f];var F=FAMS[f],v=[];
 function add(l,k){(l||[]).forEach(function(e){v.push([e[0],k,e[1]])})}
 add(F.seal,"seal");if(F.clr)add(CLR,"clr");if(F.grv)add(GRV,"grv");if(F.tap)add(TAP,"tap");if(F.brass)add(BRASS,"brass");if(F.pair)add(PAIR,"pair");
 (F.neut||[]).forEach(function(t){v.push([t,"neut",""])});
 v.sort(function(a,b){return b[0].length-a[0].length});return(CACHE[f]=v)}
function famOf(pfx,dg,hasBore,tap){
 if(pfx){if(CRP.test(pfx))return"CR";if(pfx==="QJ")return"AC";if(TIP.test(pfx)&&(tap||dg.length>=5))return"TI";if(pfx==="NA"&&tap)return"TI";return"P"}
 if(dg.charAt(0)==="0")return"TI";var n=dg.length;
 if(/^(16\d{3}|6\d{2,4})$/.test(dg)||(hasBore&&/^6\d$/.test(dg)))return tap&&n===4?"TI":"DG";
 if(n===5&&/^3[0-3]/.test(dg))return"TR";
 if(hasBore&&/^3(02|03|13|20|22|23|29|30|31|32)$/.test(dg))return"TR";
 if(n===5&&/^2[1-4]/.test(dg))return"SR";
 if(n===5&&/^11/.test(dg))return"SB";
 if(n===4&&/^(11|12|13|22|23)/.test(dg))return"SB";
 if(n===5&&/^(29|8[19])/.test(dg))return"TX";
 if(n===5&&/^5[1-4]/.test(dg))return"TH";
 if(n===4&&/^7/.test(dg))return"AC";
 if(n===4&&/^(32|33|52|53)/.test(dg))return"AD";
 if(tap)return"TI";
 return"G"}
function parseTI(s){
 var t=s.replace(/\s+/g,"").replace(/^(4T|T)-?/,""),p=t.split(/[\/\-]/).filter(Boolean);
 var cone=p[0]||"",cup="";
 if(!/\d{3}/.test(cone))return null;
 for(var i=1;i<p.length;i++){var q=p[i];if(/^(20\d{3}|9\d{4})$/.test(q))continue;
  if(/^[A-Z]{0,3}\d{2,}[A-Z]{0,2}$/.test(q)){cup=q.replace(/\D/g,"").slice(-3);break}}
 return{base:cone+(cup?"/"+cup:""),fam:"TI",sig:"TI:"+cone+(cup?"/"+cup:""),x:0,plain:1}}
function parse(raw,tname){
 if(raw==null)return null;
 var s=String(raw).toUpperCase().replace(/ /g," ").replace(/\*/g,"").trim();
 s=s.replace(/^(DGBB|SRB|CRB|TRB|ACBB)\s+/,"").replace(/^(7E|5S|2LA)-/,"").replace(/^ML(?=6)/,"").replace(/^HR(?=3\d)/,"").replace(/^4T[-\s]?(?=[A-Z0-9])/,"");
 var tap=/TAPER/i.test(tname||"");
 var m=/^([A-Z]{1,6}?)\s*-?\s*(?=\d)/.exec(s),pfx=m?m[1]:"",rest=m?s.slice(m[0].length):s;
 if(!/^\d/.test(rest))return null;
 var bm=/^(\d{1,7})(?:\/(\d+(?:\.\d+)?)(?=[^\d.]|$))?/.exec(rest);if(!bm)return null;
 var dg=bm[1],bore=bm[2]||"",hasBore=!!bore;
 if(!pfx&&dg.length<2)return null;
 var f=famOf(pfx,dg,hasBore,tap);
 if(f==="TI")return parseTI(s);
 var base=pfx+dg+(bore?"/"+bore:""),suf=rest.slice(bm[0].length);
 if(pfx&&f==="P"){var xm=/^(?:\s?X\s?\d+(?:\.\d+)?){1,2}/.exec(suf);if(xm){base+=xm[0].replace(/\s/g,"");suf=suf.slice(xm[0].length)}}
 if(!pfx&&dg.length<3&&!hasBore)return null;
 var segs=suf.split(/[\s\-_.\/,;+()]+/).filter(Boolean);for(var q=0;q<segs.length;q++){if(segs[q]==="C"&&q+1<segs.length&&!/^\d$/.test(segs[q+1]))segs[q]=""}
 var c=segs.join(""),F=FAMS[f],V=vocab(f);
 var r={seal:"",clr:"",grv:"",tap:"",brass:"",ang:"",pair:""},x=0,unk="",i=0;
 if(F.ang){var am=/^(AC|A|B|C(?!\d))/.exec(c);if(am){r.ang=am[1];i=am[1].length}}
 function flushUnk(){if(unk){if(typeof __UNK!=="undefined")__UNK.push(f+":"+unk);if(F.strict||(F.strictDigit&&/\d/.test(unk)))x=1;unk=""}}
 outer:while(i<c.length){
  var rem=c.slice(i);
  for(var k=0;k<V.length;k++){var e=V[k];if(rem.lastIndexOf(e[0],0)===0){
    flushUnk();if(e[1]!=="neut"&&!r[e[1]])r[e[1]]=e[2];i+=e[0].length;continue outer}}
  var fm=FLAG.exec(rem);
  if(fm){flushUnk();x=1;i+=fm[0].length;continue}
  unk+=c.charAt(i);i++}
 flushUnk();
 var p=[base];
 if(F.seal)p.push(r.seal||"O");
 if(r.clr&&r.clr!=="CN")p.push(r.clr);
 if(r.grv)p.push(r.grv);if(r.tap)p.push(r.tap);if(r.brass)p.push(r.brass);
 if(r.ang)p.push("a"+r.ang);if(r.pair)p.push(r.pair);
 return{base:base,fam:f,sig:p.join("|"),x:x,plain:c.length===0?1:0}}
return{parse:parse}
})();
if(typeof module!=="undefined")module.exports=JKBEQ;
