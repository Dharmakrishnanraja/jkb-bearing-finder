import re,json,sys
P=re.compile(r'^\d{1,3}(,\d{3})*$')
def parse(fn):
    out=[];sec=None
    for ln in open(fn,encoding='utf8'):
        segs=[s.strip() for s in re.split(r'\s{2,}',ln.strip()) if s.strip()]
        for i,s in enumerate(segs):
            if P.match(s) and i>0:
                d=segs[i-1]
                if not P.match(d): out.append(d)
    return out
for n in ('ind','imp'):
    L=parse(n+'.txt'); print(n,len(L),len(set(L)))
    json.dump(L,open(n+'_raw.json','w'))
