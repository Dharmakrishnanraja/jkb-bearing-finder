/* ===== Quotation system ===== */
const CO={n:"JAYAKUMAR BEARINGS",a:"112, Cotton Market, Near KFC & Behind Maruti Car Showroom, Rajapalayam – 626117",p:"Ph: +91 99429 83003, +91 63698 85567",e:"jkbearingrjpm@gmail.com",g:"33ALEPP5843M2ZP"};
let QT=[],QC={name:"",addr:"",town:"",gstin:"",phone:"",no:"",ts:0,note:""},QI=null;
const qkey=i=>META.brands[ROWS[i][1]]+"|"+ROWS[i][0];
let QMAP=null;const qfind=k=>{if(!QMAP){QMAP=new Map();ROWS.forEach((r,i)=>QMAP.set(META.brands[r[1]]+"|"+r[0],i))}return QMAP.get(k)};
function qsave(){try{localStorage.setItem("jkb_quote",JSON.stringify({t:QT,c:QC}))}catch(e){}}
function qload(){try{const s=JSON.parse(localStorage.getItem("jkb_quote")||"null");if(s){QT=s.t||[];Object.assign(QC,s.c||{})}}catch(e){}}
const qlines=()=>QT.map(t=>{const i=qfind(t.k);if(i==null)return null;const r=ROWS[i],c=calc(r);return{i,r,c,q:t.q,b:bnm(r),k:t.k}}).filter(Boolean);
function qtot(L){let tx=0,gs=0,nt=0;L.forEach(l=>{if(l.c){tx+=l.c.tx*l.q;gs+=l.c.gst*l.q;nt+=l.c.nett*l.q}});return{tx,gs,nt}}
function qfab(){const f=$("qfab");f.querySelector("b").textContent=QT.length;f.classList.toggle("has",QT.length>0)}
function qadd(i){const k=qkey(i),q=qty[i]??Math.max(1,+$("dq").value||1),e=QT.find(t=>t.k===k);if(e)e.q=q;else QT.push({k,q});qsave();qfab();if(!$("qm").hidden)qdraw()}
(function(){
 const st=document.createElement("style");st.textContent=`
.qa{background:linear-gradient(135deg,#ff7a00,#ff4500);color:#fff;border:0;border-radius:10px;padding:6px 11px;font:inherit;font-weight:800;cursor:pointer;white-space:nowrap}.qa:active{transform:scale(.92)}.qa.ok{background:#16a34a}
#qfab{position:fixed;right:16px;bottom:16px;z-index:50;background:linear-gradient(135deg,#ff7a00,#ff4500);color:#fff;border:0;border-radius:30px;padding:12px 18px;font:inherit;font-weight:900;font-size:15px;box-shadow:0 8px 26px rgba(0,0,0,.55);cursor:pointer}#qfab b{background:#fff;color:#d63a00;border-radius:12px;padding:1px 8px;margin-left:6px}
#qm{position:fixed;inset:0;z-index:200;background:rgba(0,0,0,.72);overflow:auto;padding:14px}#qm[hidden]{display:none}
.qbox{max-width:980px;margin:0 auto;background:#14151c;border:1px solid rgba(255,255,255,.18);border-radius:22px;padding:16px;color:#fff}
.qbox h2{margin:0 0 4px;color:#ffb066;font-size:20px}.qbox .qs{color:#aab;font-size:12.5px;margin-bottom:10px}
.qf{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin:10px 0}.qf label{font-size:12px;color:#ffb066;font-weight:700;display:block}.qf input,.qf textarea{width:100%;box-sizing:border-box;border-radius:10px;border:1px solid #444;background:#fff;color:#111;padding:8px;font:inherit}.qf .w{grid-column:1/-1}
#ql{overflow-x:auto}.qt{width:100%;border-collapse:collapse;font-size:13px;margin:8px 0}.qt th{background:#ff5a00;padding:6px 4px;text-align:right}.qt th:nth-child(-n+3){text-align:left}.qt td{padding:6px 4px;border-bottom:1px solid #333;text-align:right}.qt td:nth-child(-n+3){text-align:left}.qt .q{width:56px;background:#fff;color:#111}.qt .x{background:#b91c1c;color:#fff;border:0;border-radius:8px;padding:4px 9px;cursor:pointer}
.qsum{text-align:right;font-weight:800;line-height:1.7}.qsum big{font-size:20px;color:#ffb066}
.qb{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.qb button{border:0;border-radius:12px;padding:11px 16px;font:inherit;font-weight:800;cursor:pointer;color:#fff;background:#3b3f55}.qb .pp{background:linear-gradient(135deg,#ff7a00,#ff4500)}.qb .wa2{background:#25d366}
.qr{display:flex;justify-content:space-between;gap:10px;border-bottom:1px solid #333;padding:10px 4px;font-size:14px}.qrb{display:flex;flex-direction:column;gap:6px}.qrb button{border:0;border-radius:9px;padding:7px 10px;font:inherit;font-weight:700;background:#ff5a00;color:#fff;cursor:pointer}.qrb .x{background:#b91c1c}#qa-s{width:100%;box-sizing:border-box;border-radius:10px;padding:8px;font:inherit}
@media(max-width:700px){.qf{grid-template-columns:1fr}.qt{font-size:11.5px}.qt .hm{display:none}}
@media print{#qfab,.qa,#qm{display:none!important}}`;document.head.appendChild(st);
 document.body.insertAdjacentHTML("beforeend",`<button id="qfab" type="button">📄 Quotation <b>0</b></button>
<div id="qm" hidden><div class="qbox" id="qarchbox" hidden><h2>📂 சேமித்த Quotations</h2><div class="qs">Quote எண், Customer பெயர், ஊர் அல்லது Bearing எண் மூலம் தேடலாம். “Open / Edit” அழுத்தி திருத்தலாம்.</div><div class="qf"><div class="w"><input id="qa-s" placeholder="🔎 தேடுக…"></div></div><div id="qa-l"></div><div class="qs" id="qa-bk" style="margin-top:10px">💾 <b>Backup:</b> சேமித்த Quotation-கள் இந்த Browser-ல் மட்டுமே இருக்கும். அடிக்கடி “Export” செய்து கோப்பை பாதுகாக்கவும்; வேறு Phone/Computer-ல் “Import” செய்யலாம். <span id="qa-bt"></span></div><div class="qb"><button id="qa-back">⬅ திரும்பு</button><button id="qa-exp">⬇ Export (Backup)</button><button id="qa-imp">⬆ Import</button><input type="file" id="qa-file" accept=".json,application/json" hidden></div></div><div class="qbox" id="qmain"><h2>📄 Quotation (விலைப்புள்ளி)</h2><div class="qs">வரிசையில் “＋ Quote” அழுத்திய பேரிங்கள் இங்கே சேரும். Customer விவரம் நிரப்பி A4 PDF உருவாக்கலாம்.</div>
<div class="qf"><div><label>Customer பெயர் / Name</label><input id="qc-name"></div><div><label>ஊர் / Town</label><input id="qc-town"></div>
<div class="w"><label>முகவரி / Address</label><textarea id="qc-addr" rows="2"></textarea></div>
<div><label>GST Number</label><input id="qc-gstin" placeholder="33XXXXXXXXXXXXX"></div><div><label>Mobile (WhatsApp) – 10 இலக்கம்</label><input id="qc-phone" inputmode="tel"></div>
<div class="w"><label>Quote No. (தானாக வரும்)</label><input id="qc-no" readonly style="background:#ddd;font-weight:800"></div>
<div class="w"><label>குறிப்பு / Note (விருப்பம்)</label><input id="qc-note"></div></div>
<div id="ql"></div>
<div class="qb"><button class="pp" id="q-pdf">⬇ PDF உருவாக்கு</button><button class="wa2" id="q-wa">WhatsApp-ல் அனுப்பு</button><button id="q-prt">🖨 Print</button><button id="q-save">💾 Save</button><button id="q-arch">📂 சேமித்தவை</button><button id="q-clr">🆕 புதிய Quotation</button><button id="q-close">✖ மூடு</button></div></div></div>`);
})();
const QF={name:"qc-name",town:"qc-town",addr:"qc-addr",gstin:"qc-gstin",phone:"qc-phone",no:"qc-no",note:"qc-note"};
function qarc(){try{return JSON.parse(localStorage.getItem("jkb_qarch")||"[]")}catch(e){return[]}}
function qarcSet(a){try{localStorage.setItem("jkb_qarch",JSON.stringify(a))}catch(e){alert("இந்த Browser-ல் சேமிக்க முடியவில்லை")}}
function qseq(){try{return +localStorage.getItem("jkb_qseq")||0}catch(e){return 0}}
function qnext(){let m=qseq();qarc().forEach(x=>{const n=+String(x.no).split("-").pop()||0;if(n>m)m=n});return m+1}
function qno(){if(!QC.no){QC.no="JKB-"+new Date().getFullYear()+"-"+String(qnext()).padStart(4,"0");QC.ts=Date.now()}return QC.no}
const esc=s=>String(s==null?"":s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
function qkeep(){if(!QT.length)return false;qno();const L=qlines(),T=qtot(L),a=qarc(),
 rec={no:QC.no,ts:QC.ts||Date.now(),upd:Date.now(),c:Object.assign({},QC),t:QT.map(x=>({k:x.k,q:x.q})),n:QT.length,tot:Math.round(T.nt),br:L.map(l=>l.r[0]+" ("+l.b+")")};
 const j=a.findIndex(x=>x.no===QC.no);if(j>=0)a[j]=rec;else a.push(rec);qarcSet(a);
 try{localStorage.setItem("jkb_qseq",String(Math.max(qseq(),+QC.no.split("-").pop()||0)))}catch(e){}return true}
function qdraw(){const L=qlines(),T=qtot(L);
 $("ql").innerHTML=L.length?`<table class="qt"><thead><tr><th>#</th><th>Bearing No.</th><th>Brand</th><th class="hm">List Price</th><th class="hm">Disc.</th><th>Taxable</th><th>Nett</th><th>Qty</th><th>Total</th><th></th></tr></thead><tbody>`+
  L.map((l,n)=>`<tr><td>${n+1}</td><td><b>${l.r[0]}</b></td><td>${l.b}</td>`+(l.c?`<td class="hm">${inr(l.c.rsp)}</td><td class="hm">${inr(l.c.disc)}</td><td>${inr(l.c.tx)}</td><td>${inr(l.c.nett)}</td>`:`<td colspan="4">${l.r[7]===1?"Call for Price":"Not in list"}</td>`)+
  `<td><input class="q" type="number" min="1" value="${l.q}" data-qk="${l.k}"></td><td><b>${l.c?inr(l.c.nett*l.q):"—"}</b></td><td><button class="x" data-qx="${l.k}">✕</button></td></tr>`).join("")+`</tbody></table>
 ${L.some(l=>!l.c)?'<div class="qsum" style="color:#ffb066;font-size:13px;margin-bottom:6px">⚠ “Call for Price” பொருள்கள் Total-ல் சேராது.</div>':""}<div class="qsum">Taxable: ₹${inr(T.tx)}<br>GST: ₹${inr(T.gs)}<br>Grand Total: <big>₹${inr(Math.round(T.nt))}</big></div>`:`<p style="padding:18px;text-align:center;color:#aab">இன்னும் எதுவும் சேர்க்கவில்லை. தேடல் வரிசையில் “＋ Quote” அழுத்தவும்.</p>`}
function qopen(){qno();for(const k in QF)$(QF[k]).value=QC[k]||"";if(!QC.name&&$("cust").value)$("qc-name").value=QC.name=$("cust").value;if(!QC.gstin&&$("gstin").value)$("qc-gstin").value=QC.gstin=$("gstin").value;qdraw();$("qmain").hidden=false;$("qarchbox").hidden=true;$("qm").hidden=false}
$("qfab").onclick=qopen;$("q-close").onclick=()=>{$("qm").hidden=true};
$("qm").addEventListener("input",e=>{const id=e.target.id;for(const k in QF)if(QF[k]===id){QC[k]=e.target.value;qsave();return}
 const k=e.target.dataset.qk;if(k){const t=QT.find(x=>x.k===k);if(t){t.q=Math.max(1,+e.target.value||1);qsave();const pos=e.target.selectionStart;qdraw();const n=document.querySelector(`[data-qk="${CSS.escape(k)}"]`);if(n){n.focus()}}}});
$("qm").addEventListener("click",e=>{const x=e.target.dataset.qx;if(x){QT=QT.filter(t=>t.k!==x);qsave();qfab();qdraw()}});
function qnew(){QT=[];QC={name:"",addr:"",town:"",gstin:"",phone:"",no:"",ts:0,note:""};qno();for(const k in QF)$(QF[k]).value=QC[k]||"";qsave();qfab();qdraw()}
$("q-clr").onclick=()=>{if(QT.length){qkeep();}qnew()};
$("q-save").onclick=()=>{if(!qchk())return;const b=$("q-save");b.textContent="✓ சேமிக்கப்பட்டது "+QC.no;setTimeout(()=>b.textContent="💾 Save",1800)};
function qarcDraw(){const s=($("qa-s").value||"").toLowerCase(),a=qarc().sort((x,y)=>y.ts-x.ts).filter(x=>!s||(x.no+" "+x.c.name+" "+x.c.town+" "+x.c.gstin+" "+x.c.phone+" "+x.br.join(" ")).toLowerCase().includes(s));
 $("qa-l").innerHTML=a.length?a.map(x=>`<div class="qr"><div><b>${esc(x.no)}</b> · ${new Date(x.ts).toLocaleDateString("en-IN")}<br>${esc(x.c.name||"—")}${x.c.town?", "+esc(x.c.town):""}<br><small>${x.n} items · ₹${inr(x.tot)}</small><br><small>${esc(x.br.slice(0,6).join(", "))}${x.br.length>6?" …":""}</small></div><div class="qrb"><button data-qo="${esc(x.no)}">✏ Open / Edit</button><button data-qd="${esc(x.no)}" class="x">🗑</button></div></div>`).join(""):"<p style='padding:16px;text-align:center;color:#aab'>சேமித்த Quotation எதுவும் இல்லை</p>"}
$("q-arch").onclick=()=>{if(QT.length)qkeep();$("qmain").hidden=true;$("qarchbox").hidden=false;$("qa-s").value="";qarcDraw()};
$("qa-back").onclick=()=>{$("qarchbox").hidden=true;$("qmain").hidden=false};$("qa-s").oninput=qarcDraw;
$("qm").addEventListener("click",e=>{const o=e.target.dataset.qo,d=e.target.dataset.qd;
 if(o){if(QT.length&&QC.no!==o)qkeep();const x=qarc().find(z=>z.no===o);if(!x)return;QT=x.t.map(t=>({k:t.k,q:t.q}));QC=Object.assign({name:"",addr:"",town:"",gstin:"",phone:"",no:"",ts:0,note:""},x.c);qsave();qfab();qopen()}
 if(d&&confirm("இந்த Quotation "+d+"-ஐ நிரந்தரமாக நீக்கவா?")){qarcSet(qarc().filter(z=>z.no!==d));qarcDraw()}});
document.addEventListener("click",e=>{const b=e.target.closest(".qa");if(!b)return;qadd(+b.dataset.qa);b.classList.add("ok");b.textContent="✓ சேர்ந்தது";setTimeout(()=>{b.classList.remove("ok");b.textContent="＋ Quote"},1200)});

/* ---- Backup: export / import of saved quotations ---- */
function qbkInfo(){let t=0;try{t=+localStorage.getItem("jkb_qbk")||0}catch(e){}$("qa-bt").textContent=t?"கடைசி Backup: "+new Date(t).toLocaleString("en-IN"):"இன்னும் Backup எடுக்கவில்லை."}
$("q-arch").addEventListener("click",qbkInfo);
$("qa-exp").onclick=()=>{const a=qarc();if(!a.length){alert("சேமித்த Quotation எதுவும் இல்லை.");return}
 const o={app:"JKB-Quotations",v:1,exported:new Date().toISOString(),seq:qseq(),arch:a},b=new Blob([JSON.stringify(o)],{type:"application/json"}),u=URL.createObjectURL(b),l=document.createElement("a"),d=new Date(),p=n=>String(n).padStart(2,"0");
 l.href=u;l.download=`JKB_Quotations_Backup_${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}.json`;document.body.appendChild(l);l.click();setTimeout(()=>{URL.revokeObjectURL(u);l.remove()},500);
 try{localStorage.setItem("jkb_qbk",String(Date.now()))}catch(e){}qbkInfo()};
$("qa-imp").onclick=()=>$("qa-file").click();
$("qa-file").onchange=e=>{const f=e.target.files[0];e.target.value="";if(!f)return;const r=new FileReader();r.onload=()=>{try{const o=JSON.parse(r.result);if(o.app!=="JKB-Quotations"||!Array.isArray(o.arch))throw 0;
  const cur=qarc(),m=new Map(cur.map(x=>[x.no,x]));let add=0,upd=0;o.arch.forEach(x=>{if(!x||!x.no||!x.c||!Array.isArray(x.t))return;const y=m.get(x.no);if(!y){m.set(x.no,x);add++}else if((x.ts||0)>(y.ts||0)){m.set(x.no,x);upd++}});
  qarcSet([...m.values()]);try{localStorage.setItem("jkb_qseq",String(Math.max(qseq(),+o.seq||0)))}catch(e){}qarcDraw();alert(`Import முடிந்தது: புதிதாக ${add}, புதுப்பிக்கப்பட்டது ${upd}.`)}catch(x){alert("இது சரியான JKB Quotation Backup கோப்பு அல்ல.")}};r.readAsText(f)};
/* ---- A4 page renderer (canvas) ---- */
const PW=1654,PH=2339,FN='"Noto Sans Tamil","Latha","Nirmala UI","Segoe UI",Arial,sans-serif';
function loadLogo(){return new Promise(ok=>{const s=document.querySelector(".phead img");if(!s){ok(null);return}const im=new Image();im.onload=()=>ok(im);im.onerror=()=>ok(null);im.src=s.src})}
function wrap(g,t,w){const out=[];String(t||"").split(/\n/).forEach(p=>{let l="";p.split(/\s+/).forEach(wd=>{const x=l?l+" "+wd:wd;if(g.measureText(x).width>w&&l){out.push(l);l=wd}else l=x});out.push(l)});return out}
async function qpages(){const L=qlines(),T=qtot(L),logo=await loadLogo(),gp=+$("gst").value||0;
 const M=70,pages=[];let cv,g,y,pn=0;
 const COL=[["#",56,"c"],["Bearing Number",0,"l"],["Make",150,"l"],["Qty",70,"c"],["List Price",140,"r"],["Disc.",120,"r"],["Taxable",140,"r"],["Nett (Incl. GST)",180,"r"],["Total",160,"r"]];
 const fixed=COL.reduce((s,c)=>s+c[1],0);COL[1][1]=PW-2*M-fixed;
 const X=[];let ax=M;COL.forEach(c=>{X.push(ax);ax+=c[1]});
 const T_=(t,x,yy,al,fs,wt,col)=>{g.font=`${wt||400} ${fs}px ${FN}`;g.fillStyle=col||"#111";g.textAlign=al;g.textBaseline="alphabetic";g.fillText(t,x,yy)};
 function head(){cv=document.createElement("canvas");cv.width=PW;cv.height=PH;g=cv.getContext("2d");g.fillStyle="#fff";g.fillRect(0,0,PW,PH);pn++;
  g.fillStyle="#ff5a00";g.fillRect(0,0,PW,26);
  if(logo)g.drawImage(logo,M,46,165,165);
  T_(CO.n,PW/2,112,"center",66,900,"#c2410c");T_("BEARING SALES · RAJAPALAYAM",PW/2,150,"center",25,700,"#444");
  T_(CO.a,PW/2,184,"center",23,400,"#333");T_(CO.p+"  ·  "+CO.e,PW/2,214,"center",23,400,"#333");
  T_("GSTIN: "+CO.g,PW/2,246,"center",25,800,"#111");
  g.fillStyle="#111";g.fillRect(M,262,PW-2*M,4);
  T_("QUOTATION",PW/2,322,"center",44,900,"#111");
  const d=new Date(QC.ts||Date.now()).toLocaleDateString("en-IN");T_("Quote No: "+qno(),M,322,"left",27,700);T_("Date: "+d,PW-M,322,"right",27,700);
  y=348;
  if(pn===1){g.fillStyle="#f6f7fb";g.fillRect(M,y,PW-2*M,230);g.strokeStyle="#bbb";g.lineWidth=2;g.strokeRect(M,y,PW-2*M,230);
   T_("To:",M+20,y+38,"left",24,700,"#c2410c");
   T_(QC.name||"—",M+20,y+80,"left",36,900);
   g.font=`400 27px ${FN}`;let yy=y+118;wrap(g,QC.addr,PW-2*M-440).slice(0,2).forEach(l=>{T_(l,M+20,yy,"left",27);yy+=34});
   T_("Town: "+(QC.town||"—"),M+20,y+206,"left",27,700);
   T_("GSTIN: "+(QC.gstin||"—"),PW-M-20,y+80,"right",27,700);T_("Mobile: "+(QC.phone||"—"),PW-M-20,y+125,"right",27,700);
   y+=250}
  g.fillStyle="#1a1a1a";g.fillRect(M,y,PW-2*M,56);COL.forEach((c,k)=>{const al=c[2],tx=al==="r"?X[k]+c[1]-10:al==="c"?X[k]+c[1]/2:X[k]+10;T_(c[0],tx,y+37,al==="r"?"right":al==="c"?"center":"left",c[0].length>14?21:23,800,"#fff")});
  y+=56;pages.push(cv)}
 head();const RH=72,LIM=PH-380;
 L.forEach((l,n)=>{if(y+RH>LIM)head();
  if(n%2){g.fillStyle="#fafafa";g.fillRect(M,y,PW-2*M,RH)}
  g.strokeStyle="#ddd";g.lineWidth=1.5;g.beginPath();g.moveTo(M,y+RH);g.lineTo(PW-M,y+RH);g.stroke();
  const v=[String(n+1),null,l.b,String(l.q),l.c?inr(l.c.rsp):"",l.c?inr(l.c.disc):"",l.c?inr(l.c.tx):"",l.c?inr(l.c.nett):"",l.c?inr(l.c.nett*l.q):""];
  v.forEach((s,k)=>{const c=COL[k],al=c[2],tx=al==="r"?X[k]+c[1]-10:al==="c"?X[k]+c[1]/2:X[k]+10,ta=al==="r"?"right":al==="c"?"center":"left";
   if(k===1){T_(l.r[0],tx,y+33,"left",29,900);{let fz=20;g.font=`400 ${fz}px ${FN}`;const tn=META.types[l.r[2]];while(fz>14&&g.measureText(tn).width>c[1]-24){fz--;g.font=`400 ${fz}px ${FN}`}T_(tn,tx,y+61,"left",fz,400,"#555")}}
   else if(k===2){g.font=`800 24px ${FN}`;if(g.measureText(s).width>c[1]-14&&s.indexOf(" ")>0){const i0=s.indexOf(" ");T_(s.slice(0,i0),tx,y+33,"left",24,800);T_(s.slice(i0+1),tx,y+60,"left",22,800)}else T_(s,tx,y+45,"left",24,800)}else if(k===3)T_(s,tx,y+45,"center",28,900);
   else if(k===7||k===8)T_(s||(k===7?(l.r[7]===1?"Call for Price":"N/A"):""),tx,y+45,ta,27,800);else T_(s,tx,y+45,ta,26)});
  y+=RH});
 if(y+300>PH-120)head();
 y+=18;const bx=PW-M-640,hg=gp/2,sg=Math.round(T.gs*50)/100;g.fillStyle="#f6f7fb";g.fillRect(bx,y,640,217);g.strokeStyle="#bbb";g.strokeRect(bx,y,640,217);
 T_("Taxable Value",bx+20,y+42,"left",27,600);T_("₹ "+inr(T.tx),bx+620,y+42,"right",27,700);
 T_("SGST "+hg+"%",bx+20,y+84,"left",27,600);T_("₹ "+inr(sg),bx+620,y+84,"right",27,700);
 T_("CGST "+hg+"%",bx+20,y+126,"left",27,600);T_("₹ "+inr(sg),bx+620,y+126,"right",27,700);
 g.fillStyle="#ff5a00";g.fillRect(bx,y+147,640,70);T_("GRAND TOTAL",bx+20,y+194,"left",30,900,"#fff");T_("₹ "+inr(Math.round(T.nt)),bx+620,y+194,"right",36,900,"#fff");
 let ny=y+40;g.font=`400 24px ${FN}`;
 T_("Terms:",M,ny,"left",25,800,"#c2410c");ny+=36;
 T_("Payments",M,ny,"left",25,700,"#111");T_(":  30 Days",M+190,ny,"left",25,700,"#111");ny+=36;
 T_("Delivery",M,ny,"left",25,700,"#111");T_(":  Ready Stock against Your Purchase Order",M+190,ny,"left",25,700,"#111");ny+=40;
 ["• Prices are Discounted List Price + GST "+gp+"%. Rates subject to change.","• Quotation valid for 7 days. Stock subject to availability."].concat(L.some(l=>!l.c)?["• “Call for Price” items are not in the Total."]:[]).forEach(t=>{T_(t,M,ny,"left",23,400,"#333");ny+=32});
 if(QC.note){wrap(g,"Note: "+QC.note,bx-M-30).slice(0,3).forEach(t=>{T_(t,M,ny,"left",23,600,"#111");ny+=32})}
 pages.forEach((p,k)=>{const h=p.getContext("2d");h.fillStyle="#ff5a00";h.fillRect(0,PH-26,PW,26);h.font=`400 22px ${FN}`;h.fillStyle="#666";h.textAlign="center";h.fillText(`${CO.n} · ${CO.e} · Page ${k+1}/${pages.length}`,PW/2,PH-44)});
 return pages}
function qpdf(pages){const enc=s=>new TextEncoder().encode(s),parts=[],off=[];let len=0;const push=b=>{if(typeof b==="string")b=enc(b);parts.push(b);len+=b.length};
 const n=pages.length,jp=pages.map(p=>{const d=p.toDataURL("image/jpeg",.92).split(",")[1],bin=atob(d),u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);return u});
 const o=(id,f)=>{off[id]=len;push(`${id} 0 obj\n`);f();push("\nendobj\n")};push("%PDF-1.4\n");
 o(1,()=>push("<< /Type /Catalog /Pages 2 0 R >>"));
 o(2,()=>push(`<< /Type /Pages /Count ${n} /Kids [${pages.map((_,i)=>(3+i*3)+" 0 R").join(" ")}] >>`));
 pages.forEach((_,i)=>{const b=3+i*3;
  o(b,()=>push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Resources << /XObject << /I ${b+1} 0 R >> >> /Contents ${b+2} 0 R >>`));
  o(b+1,()=>{push(`<< /Type /XObject /Subtype /Image /Width ${PW} /Height ${PH} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jp[i].length} >>\nstream\n`);push(jp[i]);push("\nendstream")});
  const c="q 595.28 0 0 841.89 0 0 cm /I Do Q";o(b+2,()=>push(`<< /Length ${c.length} >>\nstream\n${c}\nendstream`))});
 const xo=len,tot=3+n*3;push(`xref\n0 ${tot}\n0000000000 65535 f \n`);for(let i=1;i<tot;i++)push(String(off[i]).padStart(10,"0")+" 00000 n \n");
 push(`trailer\n<< /Size ${tot} /Root 1 0 R >>\nstartxref\n${xo}\n%%EOF`);return new Blob(parts,{type:"application/pdf"})}
const qchk=()=>{if(!qlines().length){alert("முதலில் பேரிங்களை Quotation-ல் சேர்க்கவும் (＋ Quote).");return false}qkeep();return true};
const qfile=()=>"JKB_Quotation_"+qno()+(QC.name?"_"+QC.name.replace(/[^A-Za-z0-9]+/g,"_"):"")+".pdf";
$("q-pdf").onclick=async()=>{if(!qchk())return;const b=qpdf(await qpages()),a=document.createElement("a");a.href=URL.createObjectURL(b);a.download=qfile();a.click()};
$("q-wa").onclick=async()=>{if(!qchk())return;const b=qpdf(await qpages()),f=new File([b],qfile(),{type:"application/pdf"}),L=qlines(),T=qtot(L);
 const msg=`வணக்கம் ${QC.name||""}, Jayakumar Bearings – Quotation ${qno()}\n${L.length} items · Grand Total ₹${inr(Math.round(T.nt))}\n112 Cotton Market, Rajapalayam · +91 99429 83003`;
 try{if(navigator.canShare&&navigator.canShare({files:[f]})){await navigator.share({files:[f],text:msg,title:"Quotation"});return}}catch(e){if(e&&e.name==="AbortError")return}
 const a=document.createElement("a");a.href=URL.createObjectURL(b);a.download=qfile();a.click();
 let ph=(QC.phone||"").replace(/\D/g,"");if(ph.length===10)ph="91"+ph;
 setTimeout(()=>{alert("PDF பதிவிறக்கமானது. திறக்கும் WhatsApp-ல் அந்த PDF-ஐ இணைத்து (📎) அனுப்பவும்.");window.open("https://wa.me/"+ph+"?text="+encodeURIComponent(msg),"_blank")},400)};
$("q-prt").onclick=async()=>{if(!qchk())return;const pg=await qpages(),w=window.open("","_blank");if(!w){alert("Pop-up அனுமதிக்கவும்");return}
 w.document.write(`<!doctype html><title>Quotation</title><style>@page{size:A4;margin:0}html,body{margin:0;background:#fff}img{display:block;width:210mm;height:297mm;page-break-after:always}</style>`+pg.map(p=>`<img src="${p.toDataURL("image/jpeg",.92)}">`).join(""));w.document.close();w.onload=()=>setTimeout(()=>w.print(),300);setTimeout(()=>{try{w.print()}catch(e){}},1200)};
qload();qfab();
