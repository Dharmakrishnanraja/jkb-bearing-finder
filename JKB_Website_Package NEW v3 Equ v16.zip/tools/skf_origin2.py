# Origin from the two price lists: SKF India MRP list (Domestic) / SKF Imported RSP 4-Dec-2025 (Imported). Prices ignored.
import json,re,csv
O='/home/claude/org/'
d=json.load(open('jkb_data.json'));M=d['meta'];T=M['types'];skf=M['brands'].index('SKF')
unit_origin=json.load(open('/home/claude/hu/hu_origin.json'))
old=json.load(open('skf_origin.rule_based.json'))
n=lambda s:re.sub(r'\s+',' ',s.upper().strip())
IND=set(map(n,json.load(open(O+'ind_raw.json'))));IMP=set(map(n,json.load(open(O+'imp_raw.json'))))
CARET=set(map(n,json.load(open(O+'caret.json'))))   # '^' marked rows inside the Imported list
rows=[];st={}
for r in d['rows']:
    if r[1]!=skf:continue
    des,t=r[0],T[r[2]];k=n(des);ini,imp=k in IND,k in IMP
    if des in unit_origin and (t.startswith('Unit –') or t.startswith('Insert Bearing –')):
        o=1 if unit_origin[des]=='Domestic' else 2;s='UNIT';note='Housing-unit price list page header ('+unit_origin[des]+')'
    elif ini and imp:
        o=1;s='BOTH';note='In SKF India (Domestic) list AND Imported list'+(' ; marked ^ in Imported list' if k in CARET else ' ; NOT marked ^ in Imported list')
    elif ini: o=1;s='DOM';note='Only in SKF India list'
    elif imp: o=2;s='IMP';note='Only in Imported list'
    else: o=2;s='NONE';note='In neither PDF -> default Imported (earlier rule-guess was '+('Domestic' if old[des]==1 else 'Imported')+')'
    rows.append((des,t,o,s,note,k in CARET));st[s]=st.get(s,0)+1
json.dump({x[0]:x[2] for x in rows},open('skf_origin.json','w'),ensure_ascii=False)
print(st,sum(1 for x in rows if x[2]==1),sum(1 for x in rows if x[2]==2))
# not in DB
dbk=set(n(r[0]) for r in d['rows'] if r[1]==skf)
ind_missing=sorted(x for x in IND if x not in dbk);imp_missing=sorted(x for x in IMP if x not in dbk and x!='#')
json.dump({'ind_missing':ind_missing,'imp_missing':imp_missing,'rows':rows},open('/home/claude/org/result.json','w'))
print(len(ind_missing),len(imp_missing),imp_missing)
