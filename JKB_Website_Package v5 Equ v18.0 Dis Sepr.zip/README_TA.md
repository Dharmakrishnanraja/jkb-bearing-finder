# JKB Bearing Finder – Website Package (வழிகாட்டி)

## கோப்புகள்
| கோப்பு | என்ன |
|---|---|
| `finder/index.html` | முழு Bearing Finder (ஒரே கோப்பு) |
| `finder/jkb_data.json.gz` | விலை டேட்டா (இதை மாற்றினால் டேட்டா புதுப்பிக்கப்படும்) |
| `finder/manifest.webmanifest`, `finder/sw.js`, `finder/icon-*.png` | Phone-ல் App ஆக நிறுவ + Offline வேலை செய்ய |
| `products-demo.html` | உன் Products பக்கம் இப்படி இருக்கும் என்ற முன்னோட்டம் (மாதிரி) |

## Website-ல் சேர்க்கும் வழி (3 படி)
1. `finder` என்ற **முழு folder-ஐ** உன் website-ன் hosting-ல் upload செய்யவும் (எ.கா. `https://உன்தளம்/finder/`).
2. Products பக்கத்தில் இந்த block-ஐ ஒட்டவும்:
```html
<iframe id="jkbFinder" src="finder/index.html?embed=1"
  title="Jayakumar Bearings – Bearing Price Finder"
  style="width:100%;border:0;height:calc(100vh - 64px);height:calc(100dvh - 64px);min-height:560px;display:block"
  loading="lazy" allow="web-share; clipboard-write; fullscreen" allowfullscreen></iframe>
```
   `64px` = உன் website header-ன் உயரம். உன் header வேறு உயரம் என்றால் அந்த எண்ணை மாற்றவும்.
3. “Full screen / App” இணைப்பு: `<a href="finder/index.html">⛶ Full screen</a>` (இதைத் திறந்தால்தான் phone-ல் “App-ஆக நிறுவு” வரும்).

**ஏன் iframe?** Finder-ல் தனி CSS / Script உள்ளது. நேரடியாக உன் பக்கத்தில் ஒட்டினால் உன் Tailwind Style-உடன் கலந்து இரண்டும் உடையும். iframe-ல் இரண்டும் தனித்தனியாகப் பாதுகாப்பாக இருக்கும்.
**கவனம்:** iframe-ன் உயரம் திரை உயரம் − header ஆக இருக்க வேண்டும். இல்லையெனில் கீழ் வலது “Quotation” பொத்தான் திரைக்கு வெளியே போய்விடும்.

## டேட்டா புதுப்பித்தல் (புதிய Price List வந்தால்)
- புதிய PDF-ஐ என்னிடம் கொடு → நான் `jkb_data.json.gz` புதியதாக உருவாக்கித் தருவேன்.
- நீ செய்ய வேண்டியது: அந்தக் கோப்பை `finder/` folder-ல் **அதே பெயரில்** மாற்றி upload செய்தால் போதும். எல்லா வாடிக்கையாளர் / உன் phone-லும் அடுத்த முறை திறக்கும்போது தானாகப் புதுப்பிக்கும் (டேட்டாவின் புதிய பதிப்பே பயன்படுத்தப்படும்).
- Domestic/Imported வகைப்படுத்தல் மூலம்: `SKF_Domestic_Imported_Classification.csv`.

## முக்கிய எச்சரிக்கை – உன் Discount / விலை
இந்த Finder-ல் List Price, Discount, Nett எல்லாம் தெரியும். Website-ல் பொது (public) பக்கத்தில் வைத்தால் **யார் வேண்டுமானாலும் உன் Discount-ஐப் பார்க்கலாம்**. தேவையானால்: (அ) Products-ல் மறைவான / password பக்கத்தில் வை, அல்லது (ஆ) public-க்கு Discount-ஐ மறைத்த பதிப்பு செய்யலாம் (நான் செய்து தருகிறேன்).

## Backup
Quotation → “📂 சேமித்தவை” → **Export (Backup)**. வேறு device-ல் **Import**.

## Website பதிப்பு – Purchase விலை இல்லை
இந்த `finder/` பதிப்பில் TR, RTUO விலைகள் ஏற்கெனவே **Purchase + Profit%** சேர்த்த Customer விலையாக உள்ளன. Purchase விலை கோப்பில் இல்லை; Internal mode பொத்தானும் இல்லை. Profit % மாற்ற வேண்டுமானால் என்னிடம் சொல், புதிய `jkb_data.json.gz` + `index.html` தருகிறேன்.
உன் சொந்த `JKB_Bearing_Finder.html` (Internal mode உள்ளது) **website-ல் ஏற்ற வேண்டாம்**; அது உன் phone / computer-க்கு மட்டும்.
